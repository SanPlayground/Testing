import React, { useState, useEffect } from 'react';
import { Clock as ClockIcon } from 'lucide-react';
import { format } from 'date-fns';

export function Clock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center space-x-2 text-gray-600">
      <ClockIcon className="w-4 h-4" />
      <time className="font-mono">
        {format(time, 'hh:mm:ss aa')} EST
      </time>
    </div>
  );
}