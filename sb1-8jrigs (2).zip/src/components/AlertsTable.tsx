import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchAndParseFeed } from '../utils/feedParser';
import { AlertTriangle, ExternalLink, Loader2, MoveRight } from 'lucide-react';
import { Feed, IoC } from '../types';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

const ALL_FEEDS = [
  'https://rss.app/feeds/q8PRH8tu4AdQutil.xml',
  'https://rss.app/feeds/63HCCwDEBBdKLRYh.xml',
  'https://rss.app/feeds/opcuSayfDjcooBfX.xml',
  'https://rss.app/feeds/luxSgpgkvi6oQlBS.xml',
  'https://rss.app/feeds/YlxrF4C2uQ0WkPAH.xml',
  'https://rss.app/feeds/P4JuptWqCm2pfIBo.xml',
  'https://rss.app/feeds/DcYnnSwVS4GHrH2B.xml',
  'https://rss.app/feeds/WzSbvLdpfCs6r6KC.xml',
  'https://rss.app/feeds/wj7DSgbooQIelsOY.xml',
  'https://rss.app/feeds/Y9ixdQZGceFH8yq4.xml',
  'https://rss.app/feeds/swTIWKPk5mEf0gzp.xml',
  'https://rss.app/feeds/399EUe809FdBCqID.xml'
];

export function AlertsTable() {
  const queries = ALL_FEEDS.map(feed => 
    useQuery({
      queryKey: ['feed-alerts', feed],
      queryFn: () => fetchAndParseFeed(feed),
      staleTime: 5 * 60 * 1000,
    })
  );

  const isLoading = queries.some(query => query.isLoading);
  const isError = queries.some(query => query.isError);
  const feeds = queries.map(query => query.data).filter(Boolean) as Feed[];

  const allAlerts = feeds.flatMap(feed => 
    feed.items
      .filter(item => item.iocs && item.iocs.length > 0)
      .flatMap(item => 
        (item.iocs || []).map(ioc => ({
          ...ioc,
          source: feed.title,
          link: item.link,
          timestamp: new Date(item.pubDate).getTime(),
          pubDate: item.pubDate,
          title: item.title,
          description: item.description
        }))
      )
  ).sort((a, b) => b.timestamp - a.timestamp);

  const handleMoveToTriage = (alert: any) => {
    // Store the alert in localStorage for the Triage tab
    const triageAlerts = JSON.parse(localStorage.getItem('triageAlerts') || '[]');
    triageAlerts.push(alert);
    localStorage.setItem('triageAlerts', JSON.stringify(triageAlerts));
    
    // Switch to the Triage tab (index 1)
    const tabButtons = document.querySelectorAll('[role="tab"]');
    if (tabButtons[1]) {
      (tabButtons[1] as HTMLButtonElement).click();
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-24">
        <Loader2 className="w-6 h-6 animate-spin text-purple-600" />
        <span className="ml-2 text-gray-600">Loading alerts...</span>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-red-700">
        Error loading alerts
      </div>
    );
  }

  if (allAlerts.length === 0) {
    return (
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-gray-600 text-center">
        No Web3 indicators detected in any feeds
      </div>
    );
  }

  return (
    <div className="bg-white border border-gray-200 rounded-lg overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-200 bg-gray-50">
        <div className="flex items-center space-x-2">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          <h2 className="text-lg font-semibold text-gray-900">Recent Web3 Alerts</h2>
          <span className="bg-amber-100 text-amber-800 text-sm px-2 py-0.5 rounded-full">
            {allAlerts.length}
          </span>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-32">
                Actions
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Timestamp
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Type
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Value
              </th>
              <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Source
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {allAlerts.map((alert, index) => (
              <tr key={index} className="hover:bg-gray-50">
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => handleMoveToTriage(alert)}
                      className="inline-flex items-center space-x-1 px-2 py-1 bg-purple-100 text-purple-800 rounded hover:bg-purple-200 transition-colors"
                    >
                      <MoveRight className="w-4 h-4" />
                      <span className="text-sm">Triage</span>
                    </button>
                    <a
                      href={alert.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-600 hover:text-purple-800 inline-flex items-center"
                    >
                      <ExternalLink className="w-4 h-4" />
                    </a>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm text-gray-500">
                    {format(new Date(alert.pubDate), 'MMM d, yyyy hh:mm:ss aa')}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm font-medium text-gray-900 capitalize">
                    {alert.type}
                  </span>
                </td>
                <td className="px-6 py-4">
                  <code className={`px-2 py-0.5 rounded text-sm ioc-${alert.type}`}>
                    {alert.value}
                  </code>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-sm text-gray-500">
                    {alert.source}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}