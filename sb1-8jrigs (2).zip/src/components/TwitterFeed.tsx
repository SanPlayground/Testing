import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchAndParseFeed } from '../utils/feedParser';
import { FeedItem } from './FeedItem';
import { Loader2 } from 'lucide-react';

const TWITTER_FEEDS = [
  'https://rss.app/feeds/q8PRH8tu4AdQutil.xml', // Example feed - use your actual Web3 Twitter feeds
];

export function TwitterFeed() {
  const { data: feed, isLoading, isError, error } = useQuery({
    queryKey: ['twitter-feed'],
    queryFn: () => fetchAndParseFeed(TWITTER_FEEDS[0]),
    staleTime: 5 * 60 * 1000,
  });

  if (isError) {
    return (
      <div className="text-center text-red-600 p-8">
        Error loading Twitter feed: {(error as Error).message}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : feed ? (
        <div>
          <h2 className="text-xl font-bold mb-6 text-gray-900">
            Web3 Twitter Mentions
          </h2>
          <div className="space-y-6">
            {feed.items
              .filter(item => item.iocs && item.iocs.length > 0)
              .map((item, index) => (
                <FeedItem key={item.link + index} item={item} />
              ))}
          </div>
          {!feed.items.some(item => item.iocs && item.iocs.length > 0) && (
            <p className="text-center text-gray-600 py-8">
              No Web3 indicators found in recent tweets.
            </p>
          )}
        </div>
      ) : null}
    </div>
  );
}