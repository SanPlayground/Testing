import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { ExternalLink, AlertTriangle } from 'lucide-react';
import { FeedItem as FeedItemType } from '../types';
import { IoCSummary } from './IoCSummary';

interface FeedItemProps {
  item: FeedItemType;
}

export function FeedItem({ item }: FeedItemProps) {
  const hasIoCs = item.iocs && item.iocs.length > 0;

  return (
    <article className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow">
      {item.thumbnail && (
        <img 
          src={item.thumbnail} 
          alt={item.title}
          className="w-full h-48 object-cover rounded-md mb-4"
        />
      )}
      <div className="space-y-2">
        <div className="flex items-start justify-between gap-4">
          <h2 className="text-xl font-semibold text-gray-900 flex-1 flex items-center gap-2">
            {hasIoCs && (
              <AlertTriangle className="w-5 h-5 text-amber-500" />
            )}
            <span dangerouslySetInnerHTML={{ __html: item.title }} />
          </h2>
          <a
            href={item.link}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-600 hover:text-blue-800"
          >
            <ExternalLink className="w-5 h-5" />
          </a>
        </div>
        
        <div className="flex items-center text-sm text-gray-600 space-x-4">
          {item.creator && (
            <span className="font-medium">{item.creator}</span>
          )}
          <time className="text-gray-500">
            {formatDistanceToNow(new Date(item.pubDate), { addSuffix: true })}
          </time>
        </div>
        
        <div 
          className="text-gray-700 mt-2 prose max-w-none"
          dangerouslySetInnerHTML={{ __html: item.description }}
        />

        {hasIoCs && <IoCSummary iocs={item.iocs} />}
      </div>
    </article>
  );
}