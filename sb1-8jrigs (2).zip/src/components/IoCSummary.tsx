import React from 'react';
import { IoC } from '../types';
import { categorizeIoCs } from '../utils/web3Detector';
import { AlertTriangle, Hash, Link, Shield, Database, Key } from 'lucide-react';

const TYPE_ICONS: Record<string, React.ReactNode> = {
  ethereumAddress: <Key className="w-4 h-4" />,
  contractAddress: <Database className="w-4 h-4" />,
  transactionHash: <Hash className="w-4 h-4" />,
  ipfsHash: <Link className="w-4 h-4" />,
  ensName: <Shield className="w-4 h-4" />,
};

interface IoCSummaryProps {
  iocs: IoC[];
}

export function IoCSummary({ iocs }: IoCSummaryProps) {
  const categorized = categorizeIoCs(iocs);

  return (
    <div className="mt-4 p-4 bg-amber-50 rounded-lg border border-amber-200">
      <h3 className="text-sm font-semibold text-amber-800 mb-2 flex items-center gap-2">
        <AlertTriangle className="w-4 h-4" />
        Web3 Indicators Detected
      </h3>
      <div className="space-y-3">
        {Object.entries(categorized).map(([type, typeIocs]) => (
          <div key={type} className="space-y-1">
            <div className="flex items-center gap-1.5 text-sm font-medium text-amber-700">
              {TYPE_ICONS[type] || <Database className="w-4 h-4" />}
              {type.charAt(0).toUpperCase() + type.slice(1)}
              <span className="text-amber-500">({typeIocs.length})</span>
            </div>
            <ul className="pl-6 space-y-1">
              {typeIocs.map((ioc, index) => (
                <li key={index} className="text-sm flex items-center gap-2">
                  <code className="px-2 py-0.5 bg-amber-100 rounded text-amber-800 flex-1 overflow-hidden text-ellipsis">
                    {ioc.value}
                  </code>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}