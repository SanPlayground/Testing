import React from 'react';
import { Tab } from '@headlessui/react';
import { FeedList } from './FeedList';
import { Triage } from './Triage';
import { Rss, Shield } from 'lucide-react';

function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}

export function Tabs() {
  const categories = [
    { name: 'Twitter and RSS Feeds', icon: <Rss className="w-5 h-5" />, component: <FeedList /> },
    { name: 'Triage', icon: <Shield className="w-5 h-5" />, component: <Triage /> },
  ];

  return (
    <div className="w-full">
      <Tab.Group>
        <Tab.List className="flex space-x-1 rounded-xl bg-purple-900/20 p-1">
          {categories.map((category) => (
            <Tab
              key={category.name}
              className={({ selected }) =>
                classNames(
                  'w-full rounded-lg py-2.5 text-sm font-medium leading-5',
                  'ring-white ring-opacity-60 ring-offset-2 ring-offset-purple-400 focus:outline-none focus:ring-2',
                  selected
                    ? 'bg-white shadow text-purple-700'
                    : 'text-purple-100 hover:bg-white/[0.12] hover:text-white'
                )
              }
            >
              <div className="flex items-center justify-center space-x-2">
                {category.icon}
                <span>{category.name}</span>
              </div>
            </Tab>
          ))}
        </Tab.List>
        <Tab.Panels className="mt-4">
          {categories.map((category, idx) => (
            <Tab.Panel key={idx}>
              {category.component}
            </Tab.Panel>
          ))}
        </Tab.Panels>
      </Tab.Group>
    </div>
  );
}