import React from 'react';
import { Clock as ClockIcon, Calendar } from 'lucide-react';
import { format } from 'date-fns';

export function DateTime() {
  const [time, setTime] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex items-center space-x-6 text-white">
      <div className="flex items-center space-x-2">
        <Calendar className="w-4 h-4" />
        <time className="font-medium">
          {format(time, 'EEEE, MMMM d, yyyy')}
        </time>
      </div>
      <div className="flex items-center space-x-2">
        <ClockIcon className="w-4 h-4" />
        <time className="font-mono">
          {format(time, 'hh:mm:ss aa')} EST
        </time>
      </div>
    </div>
  );
}