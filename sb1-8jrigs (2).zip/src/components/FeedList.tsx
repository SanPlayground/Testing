import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchAndParseFeed } from '../utils/feedParser';
import { FeedItem } from './FeedItem';
import { Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { AlertsTable } from './AlertsTable';

const FEEDS = [
  'https://rss.app/feeds/q8PRH8tu4AdQutil.xml',
  'https://rss.app/feeds/63HCCwDEBBdKLRYh.xml',
  'https://rss.app/feeds/opcuSayfDjcooBfX.xml',
  'https://rss.app/feeds/luxSgpgkvi6oQlBS.xml',
  'https://rss.app/feeds/YlxrF4C2uQ0WkPAH.xml',
  'https://rss.app/feeds/P4JuptWqCm2pfIBo.xml',
  'https://rss.app/feeds/DcYnnSwVS4GHrH2B.xml',
  'https://rss.app/feeds/WzSbvLdpfCs6r6KC.xml',
  'https://rss.app/feeds/wj7DSgbooQIelsOY.xml',
  'https://rss.app/feeds/Y9ixdQZGceFH8yq4.xml',
  'https://rss.app/feeds/swTIWKPk5mEf0gzp.xml',
  'https://rss.app/feeds/399EUe809FdBCqID.xml'
];

export function FeedList() {
  const [currentFeedIndex, setCurrentFeedIndex] = React.useState(0);

  const { data: feed, isLoading, isError, error, isSuccess } = useQuery({
    queryKey: ['feed', currentFeedIndex],
    queryFn: () => fetchAndParseFeed(FEEDS[currentFeedIndex]),
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const handleNextFeed = () => {
    setCurrentFeedIndex((prev) => (prev + 1) % FEEDS.length);
  };

  const handlePrevFeed = () => {
    setCurrentFeedIndex((prev) => (prev - 1 + FEEDS.length) % FEEDS.length);
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <AlertsTable />
      
      <div className={`rounded-lg p-4 ${
        isError ? 'bg-red-50 border border-red-200' :
        isLoading ? 'bg-blue-50 border border-blue-200' :
        isSuccess ? 'bg-green-50 border border-green-200' : ''
      }`}>
        <div className="flex items-center space-x-3">
          {isLoading && (
            <>
              <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />
              <span className="text-blue-700">Loading feed...</span>
            </>
          )}
          {isError && (
            <>
              <AlertCircle className="w-5 h-5 text-red-500" />
              <span className="text-red-700">Error loading feed: {(error as Error).message}</span>
            </>
          )}
          {isSuccess && (
            <>
              <CheckCircle2 className="w-5 h-5 text-green-500" />
              <span className="text-green-700">Feed loaded successfully</span>
            </>
          )}
        </div>
      </div>

      {feed && (
        <>
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={handlePrevFeed}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              disabled={currentFeedIndex === 0}
            >
              Previous Feed
            </button>
            <h1 className="text-2xl font-bold text-center text-gray-900">
              {feed.title}
            </h1>
            <button
              onClick={handleNextFeed}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
              disabled={currentFeedIndex === FEEDS.length - 1}
            >
              Next Feed
            </button>
          </div>
          
          <div className="space-y-6">
            {feed.items.map((item, index) => (
              <FeedItem key={item.link + index} item={item} />
            ))}
          </div>
          
          {feed.items.length === 0 && (
            <p className="text-center text-gray-600">
              No items found in the last 90 days.
            </p>
          )}
        </>
      )}
    </div>
  );
}