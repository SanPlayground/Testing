import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { fetchAndParseFeed } from '../../utils/feedParser';
import { IoC } from '../../types';
import { Loader2, ExternalLink, AlertTriangle } from 'lucide-react';

// Using the feeds that contain Web3-related content
const WEB3_TWITTER_FEEDS = [
  'https://rss.app/feeds/swTIWKPk5mEf0gzp.xml', // ZachXBT
  'https://rss.app/feeds/Y9ixdQZGceFH8yq4.xml', // The Block
  'https://rss.app/feeds/opcuSayfDjcooBfX.xml', // Crypto Twitter
  'https://rss.app/feeds/luxSgpgkvi6oQlBS.xml', // DeFi Updates
  'https://rss.app/feeds/YlxrF4C2uQ0WkPAH.xml'  // NFT News
];

export const Twitter: React.FC = () => {
  const [currentFeedIndex, setCurrentFeedIndex] = React.useState(0);

  const { data: feed, isLoading, isError, error } = useQuery({
    queryKey: ['web3-twitter', currentFeedIndex],
    queryFn: () => fetchAndParseFeed(WEB3_TWITTER_FEEDS[currentFeedIndex]),
    staleTime: 5 * 60 * 1000,
  });

  const handleNextFeed = () => {
    setCurrentFeedIndex((prev) => (prev + 1) % WEB3_TWITTER_FEEDS.length);
  };

  const handlePrevFeed = () => {
    setCurrentFeedIndex((prev) => (prev - 1 + WEB3_TWITTER_FEEDS.length) % WEB3_TWITTER_FEEDS.length);
  };

  if (isError) {
    return (
      <div className="text-center text-red-600 p-8">
        Error loading feed: {(error as Error).message}
      </div>
    );
  }

  const itemsWithIoCs = feed?.items.filter(item => item.iocs && item.iocs.length > 0) || [];

  return (
    <div className="space-y-6">
      {isLoading ? (
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
        </div>
      ) : feed ? (
        <>
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={handlePrevFeed}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={currentFeedIndex === 0}
            >
              Previous Feed
            </button>
            <h2 className="text-xl font-bold text-center text-gray-900">
              {feed.title}
            </h2>
            <button
              onClick={handleNextFeed}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={currentFeedIndex === WEB3_TWITTER_FEEDS.length - 1}
            >
              Next Feed
            </button>
          </div>

          {itemsWithIoCs.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Web3 Indicators
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-24">
                      Source
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {itemsWithIoCs.map((item, itemIndex) => (
                    item.iocs?.map((ioc: IoC, iocIndex: number) => (
                      <tr key={`${itemIndex}-${iocIndex}`} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center space-x-2">
                            <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                            <div>
                              <span className="text-sm font-medium text-gray-900 capitalize">
                                {ioc.type}:
                              </span>
                              <code className={`ml-2 px-2 py-0.5 rounded text-sm ioc-${ioc.type}`}>
                                {ioc.value}
                              </code>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <a
                            href={item.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 inline-flex items-center space-x-1"
                          >
                            <ExternalLink className="w-4 h-4" />
                            <span>View</span>
                          </a>
                        </td>
                      </tr>
                    ))
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-center text-gray-600 py-8">
              No Web3 indicators found in recent tweets.
            </p>
          )}
        </>
      ) : null}
    </div>
  );
};