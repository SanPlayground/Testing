import React, { useState } from 'react';
import { Twitter } from './collections/Twitter';
import { TwitterIcon } from 'lucide-react';

export const AutonomousCollections: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'twitter'>('twitter');

  return (
    <div className="max-w-6xl mx-auto px-6">
      <div className="bg-white rounded-lg shadow-sm">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-4 p-4">
            <button
              onClick={() => setActiveTab('twitter')}
              className={`px-4 py-2 rounded-lg transition-colors ${
                activeTab === 'twitter'
                  ? 'bg-blue-600 text-white'
                  : 'text-gray-600 hover:bg-gray-100'
              }`}
            >
              <div className="flex items-center space-x-2">
                <TwitterIcon className="w-5 h-5" />
                <span>Twitter</span>
              </div>
            </button>
          </nav>
        </div>
        
        <div className="p-6">
          {activeTab === 'twitter' && <Twitter />}
        </div>
      </div>
    </div>
  );
};