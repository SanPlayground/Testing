import React, { useEffect, useState } from 'react';
import { AlertTriangle, ExternalLink, Shield, Trash2 } from 'lucide-react';
import { format } from 'date-fns';

interface TriageAlert {
  type: string;
  value: string;
  source: string;
  link: string;
  pubDate: string;
  title: string;
  description: string;
  tlp?: 'red' | 'amber' | 'green';
  confidence?: 'high' | 'med' | 'low';
}

export function Triage() {
  const [alerts, setAlerts] = useState<TriageAlert[]>([]);

  useEffect(() => {
    const storedAlerts = JSON.parse(localStorage.getItem('triageAlerts') || '[]');
    setAlerts(storedAlerts);
  }, []);

  const handleRemoveAlert = (index: number) => {
    const newAlerts = alerts.filter((_, i) => i !== index);
    setAlerts(newAlerts);
    localStorage.setItem('triageAlerts', JSON.stringify(newAlerts));
  };

  const updateAlertStatus = (index: number, field: 'tlp' | 'confidence', value: string) => {
    const newAlerts = alerts.map((alert, i) => {
      if (i === index) {
        return { ...alert, [field]: value };
      }
      return alert;
    });
    setAlerts(newAlerts);
    localStorage.setItem('triageAlerts', JSON.stringify(newAlerts));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-lg shadow-sm p-6">
        <div className="flex items-center space-x-2 mb-6">
          <Shield className="w-6 h-6 text-purple-600" />
          <h2 className="text-xl font-bold text-gray-900">Security Triage</h2>
          <span className="bg-purple-100 text-purple-800 text-sm px-2 py-0.5 rounded-full">
            {alerts.length}
          </span>
        </div>

        {alerts.length > 0 ? (
          <div className="space-y-4">
            {alerts.map((alert, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center space-x-3 min-w-0">
                    <p className="text-sm text-gray-500 whitespace-nowrap">
                      {format(new Date(alert.pubDate), 'MM/dd/yyyy HH:mm')}
                    </p>
                    <div className="flex items-center space-x-2 min-w-0">
                      <AlertTriangle className="w-4 h-4 text-amber-500 flex-shrink-0" />
                      <span className="text-sm font-medium text-gray-700 capitalize whitespace-nowrap">
                        {alert.type}:
                      </span>
                      <code className={`px-2 py-0.5 rounded text-sm ioc-${alert.type} truncate`}>
                        {alert.value}
                        {alert.tlp && alert.confidence && (
                          <span className={`ml-2 text-xs ${
                            alert.tlp === 'red' ? 'text-red-600' :
                            alert.tlp === 'amber' ? 'text-amber-600' :
                            'text-green-600'
                          }`}>
                            [{alert.tlp}:{alert.confidence}]
                          </span>
                        )}
                      </code>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 flex-shrink-0">
                    <a
                      href={alert.link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-600 hover:text-purple-800"
                    >
                      <ExternalLink className="w-5 h-5" />
                    </a>
                    <button
                      onClick={() => handleRemoveAlert(index)}
                      className="text-red-600 hover:text-red-800"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                <div className="mt-4">
                  <div className="flex items-center gap-8">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">TLP</label>
                      <div className="flex space-x-4">
                        {['red', 'amber', 'green'].map((tlp) => (
                          <label key={tlp} className="inline-flex items-center">
                            <input
                              type="radio"
                              name={`tlp-${index}`}
                              value={tlp}
                              checked={alert.tlp === tlp}
                              onChange={() => updateAlertStatus(index, 'tlp', tlp)}
                              className="form-radio h-4 w-4 text-purple-600 focus:ring-purple-500"
                            />
                            <span className={`ml-2 text-sm capitalize ${
                              tlp === 'red' ? 'text-red-600' :
                              tlp === 'amber' ? 'text-amber-600' :
                              'text-green-600'
                            }`}>
                              {tlp}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-gray-700">Confidence</label>
                      <div className="flex space-x-4">
                        {['high', 'med', 'low'].map((confidence) => (
                          <label key={confidence} className="inline-flex items-center">
                            <input
                              type="radio"
                              name={`confidence-${index}`}
                              value={confidence}
                              checked={alert.confidence === confidence}
                              onChange={() => updateAlertStatus(index, 'confidence', confidence)}
                              className="form-radio h-4 w-4 text-purple-600 focus:ring-purple-500"
                            />
                            <span className={`ml-2 text-sm capitalize ${
                              confidence === 'high' ? 'font-semibold' :
                              confidence === 'med' ? 'font-medium' :
                              'font-normal'
                            }`}>
                              {confidence}
                            </span>
                          </label>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-2">
                  <p className="text-sm text-gray-600 line-clamp-2">
                    {alert.title}
                  </p>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center text-gray-500 py-12">
            No alerts in triage. Click the "Triage" button on alerts to add them here.
          </div>
        )}
      </div>
    </div>
  );
}