export interface FeedItem {
  title: string;
  link: string;
  pubDate: string;
  description: string;
  creator?: string;
  thumbnail?: string;
  iocs?: IoC[];
}

export interface Feed {
  title: string;
  description: string;
  items: FeedItem[];
}

export interface IoC {
  type: string;
  value: string;
  index: number;
}