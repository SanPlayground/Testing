import { IoC } from '../types';

const WEB3_PATTERNS = {
  ethereumAddress: /\b0x[a-fA-F0-9]{40}\b/g,
  contractAddress: /\b0x[a-fA-F0-9]{64}\b/g,
  transactionHash: /\b0x[a-fA-F0-9]{64}\b/g,
  ipfsHash: /\b(Qm[1-9A-HJ-NP-Za-km-z]{44,}|bafy[A-Za-z2-7]{55})\b/g,
  ensName: /\b[a-zA-Z0-9-]+\.eth\b/g,
  base64: /\b[A-Za-z0-9+/]{50,}={0,2}\b/g,
  tokenId: /\b(0x[a-fA-F0-9]{1,64}|\d{1,78})\b(?=\s*(?:token|nft|id))/gi,
  uniswapPair: /\b0x[a-fA-F0-9]{40}\b(?=\s*(?:pair|pool|liquidity))/gi,
  multisig: /\bgnosis\s*safe:?\s*0x[a-fA-F0-9]{40}\b/gi
};

export function detectIoCs(text: string): IoC[] {
  const results: IoC[] = [];
  
  Object.entries(WEB3_PATTERNS).forEach(([type, pattern]) => {
    const matches = text.matchAll(pattern);
    for (const match of matches) {
      if (match[0] && !results.some(r => r.value === match[0])) {
        results.push({
          type,
          value: match[0],
          index: match.index || 0
        });
      }
    }
  });

  return results.sort((a, b) => a.index - b.index);
}

export function highlightIoCs(text: string, iocs: IoC[]): string {
  if (!iocs.length) return text;
  
  let result = text;
  let offset = 0;
  
  iocs.forEach(ioc => {
    const before = result.slice(0, ioc.index + offset);
    const after = result.slice(ioc.index + offset + ioc.value.length);
    const highlight = `<span class="ioc-highlight ioc-${ioc.type}" title="${ioc.type}">${ioc.value}</span>`;
    
    result = before + highlight + after;
    offset += highlight.length - ioc.value.length;
  });
  
  return result;
}

export function categorizeIoCs(iocs: IoC[]): Record<string, IoC[]> {
  return iocs.reduce((acc, ioc) => {
    if (!acc[ioc.type]) {
      acc[ioc.type] = [];
    }
    acc[ioc.type].push(ioc);
    return acc;
  }, {} as Record<string, IoC[]>);
}