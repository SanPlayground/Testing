import { Feed, FeedItem } from '../types';
import { subDays } from 'date-fns';
import { detectIoCs, highlightIoCs } from './web3Detector';

function parseXML(xmlText: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const parser = new DOMParser();
    try {
      const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
      
      const parserError = xmlDoc.querySelector('parsererror');
      if (parserError) {
        reject(new Error('Invalid XML format'));
        return;
      }

      resolve(xmlDoc);
    } catch (error) {
      reject(error);
    }
  });
}

function getElementText(element: Element, tagName: string): string {
  const elem = element.querySelector(tagName);
  return elem?.textContent || '';
}

function getElementAttribute(element: Element, tagName: string, attr: string): string | undefined {
  const elem = element.querySelector(tagName);
  return elem?.getAttribute(attr);
}

export async function fetchAndParseFeed(url: string): Promise<Feed> {
  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const xml = await response.text();
    const doc = await parseXML(xml);

    const channel = doc.querySelector('channel');
    if (!channel) {
      throw new Error('Invalid RSS feed format: no channel element found');
    }

    const cutoffDate = subDays(new Date(), 90);
    const items: FeedItem[] = [];

    channel.querySelectorAll('item').forEach((item: Element) => {
      const pubDateStr = getElementText(item, 'pubDate');
      const pubDate = new Date(pubDateStr);

      if (pubDate >= cutoffDate) {
        const description = getElementText(item, 'description');
        const title = getElementText(item, 'title');
        
        // Detect IoCs in both title and description
        const titleIoCs = detectIoCs(title);
        const descriptionIoCs = detectIoCs(description);
        const iocs = [...titleIoCs, ...descriptionIoCs];
        
        // Highlight IoCs in the description
        const highlightedDescription = highlightIoCs(description, descriptionIoCs);

        const feedItem: FeedItem = {
          title: highlightIoCs(title, titleIoCs),
          link: getElementText(item, 'link'),
          pubDate: pubDateStr,
          description: highlightedDescription,
          creator: getElementText(item, 'dc\\:creator') || getElementText(item, 'creator'),
          thumbnail: getElementAttribute(item, 'media\\:thumbnail', 'url') ||
                    getElementAttribute(item, 'enclosure', 'url'),
          iocs: iocs.length > 0 ? iocs : undefined
        };
        items.push(feedItem);
      }
    });

    return {
      title: getElementText(channel, 'title'),
      description: getElementText(channel, 'description'),
      items
    };
  } catch (error) {
    console.error('Feed parsing error:', error);
    throw new Error(error instanceof Error ? error.message : 'Failed to parse feed');
  }
}