import React from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Rss } from 'lucide-react';
import { DateTime } from './components/DateTime';
import { FeedList } from './components/FeedList';
import { Tabs } from './components/Tabs';

const queryClient = new QueryClient();

const App: React.FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen bg-gray-50">
        <header className="bg-purple-700 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Rss className="w-8 h-8 text-white" />
                <h1 className="text-2xl font-bold text-white">Santiago Playground!</h1>
              </div>
              <DateTime />
            </div>
          </div>
        </header>
        
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Tabs />
        </main>
      </div>
    </QueryClientProvider>
  );
};

export default App;